package com.ahom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolrApplicationTests {

	@Test
	void contextLoads() {
	}

}
