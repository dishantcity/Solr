package com.ahom.solr;

import java.io.IOException;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;

public class BasicQueries {
	
	



    public static void

    main(String[] args)

            throws SolrServerException, IOException {
        // Create a SolrClient object to connect to Solr
        SolrClient solr = new HttpSolrClient.Builder("http://localhost:8983/solr/mynewcore").build();

        // Create a SolrQuery object to specify the query
        SolrQuery query = new SolrQuery("* : *");


        // Execute the query and retrieve the results
        QueryResponse response = solr.query(query);

        // Iterate over the results and print them to the console


        for (SolrDocument document : response.getResults()) {
            System.out.println(document);
        }

        // Close the SolrClient object
        solr.close();
    }

}
