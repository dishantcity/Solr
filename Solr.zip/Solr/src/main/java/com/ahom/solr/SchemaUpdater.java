package com.ahom.solr;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;

import java.io.IOException;

public class SchemaUpdater {

    private static final String SOLR_URL = "http://localhost:8983/solr/ecommerce";

    public static void main(String[] args) throws SolrServerException, IOException {
        // Create a Solr Client object.
        SolrClient solrClient = new HttpSolrClient.Builder(SOLR_URL).build();

        // Create a SolrQuery object.
        SolrQuery query = new SolrQuery();
        query.setQuery("*:*");

        // Add facet fields to the query.
        query.setFacet(true);
        query.addFacetField("category");
        query.addFacetField("price");

        // Execute the query and get the response.
        QueryResponse response = solrClient.query(query);

    }
}
