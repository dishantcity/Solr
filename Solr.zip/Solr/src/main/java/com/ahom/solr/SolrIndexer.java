package com.ahom.solr;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.request.UpdateRequest;
import org.apache.solr.common.SolrInputDocument;

import java.io.IOException;

public class SolrIndexer {
    public static void main(String[] args) {
        // Solr server URL
        String solrUrl = "http://localhost:8983/solr/mynewcore"; // Update with your Solr core URL

        // Initialize Solr client
        SolrClient solr = new HttpSolrClient.Builder(solrUrl).build();

        try {
            // Create a SolrInputDocument and set fields
            SolrInputDocument doc = new SolrInputDocument();
            doc.addField("id", "1"); // Unique document ID
            doc.addField("title", "Sample Title");
            doc.addField("content", "This is a sample document for indexing in Solr.");

            // Add the document to the Solr index
            solr.add(doc);
            solr.commit();

            System.out.println("Document indexed successfully!");
        } catch (SolrServerException | IOException e) {
            System.err.println("Error indexing document: " + e.getMessage());
        } finally {
            try {
                solr.close();
            } catch (IOException e) {
                System.err.println("Error closing Solr client: " + e.getMessage());
            }
        }
    }
}


